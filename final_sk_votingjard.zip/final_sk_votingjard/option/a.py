from flask import Flask
import sqlite3


app = Flask(__name__)

def init_database():
    conn = sqlite3.connect('sk_voting.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            skchairman TEXT NOT NULL,
            skkagawad1 TEXT NOT NULL,
            skkagawad2 TEXT NOT NULL,
            skkagawad3 TEXT NOT NULL,
            skkagawad4 TEXT NOT NULL,
            skkagawad5 TEXT NOT NULL,
            skkagawad6 TEXT NOT NULL,
            skkagawad7 TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS skkagawad (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kagawad TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS skchairman (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chairman TEXT NOT NULL
        )
    ''')
        
    conn.commit()
    conn.close()
if __name__ == '__main__':
    init_database()
    print("Database initialized successfully!")
