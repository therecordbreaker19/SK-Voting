from flask import Flask, render_template, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
from wtforms.validators import DataRequired
import sqlite3

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  # Replace with your own secret key

# Define your forms
class SKForm(FlaskForm):
    skchairman = StringField('SK Chairman', validators=[DataRequired()])
    skkagawad1 = StringField('SK Kagawad 1', validators=[DataRequired()])
    skkagawad2 = StringField('SK Kagawad 2', validators=[DataRequired()])
    skkagawad3 = StringField('SK Kagawad 3', validators=[DataRequired()])
    skkagawad4 = StringField('SK Kagawad 4', validators=[DataRequired()])
    skkagawad5 = StringField('SK Kagawad 5', validators=[DataRequired()])
    skkagawad6 = StringField('SK Kagawad 6', validators=[DataRequired()])
    skkagawad7 = StringField('SK Kagawad 7', validators=[DataRequired()])
    submit = SubmitField('Add SK Council')

class SKKagawadForm(FlaskForm):
    skkagawad = StringField('SK Kagawad', validators=[DataRequired()])
    submit = SubmitField('Add SK Kagawad')

class SKChairmanForm(FlaskForm):
    skchairman = StringField('SK Chairman', validators=[DataRequired()])
    submit = SubmitField('Add SK Chairman')

class SKCouncilForm(FlaskForm):
    skchairman = SelectField('SK Chairman', coerce=int, validators=[DataRequired()])
    skkagawad1 = SelectField('SK Kagawad 1', coerce=int, validators=[DataRequired()])
    skkagawad2 = SelectField('SK Kagawad 2', coerce=int, validators=[DataRequired()])
    skkagawad3 = SelectField('SK Kagawad 3', coerce=int, validators=[DataRequired()])
    skkagawad4 = SelectField('SK Kagawad 4', coerce=int, validators=[DataRequired()])
    skkagawad5 = SelectField('SK Kagawad 5', coerce=int, validators=[DataRequired()])
    skkagawad6 = SelectField('SK Kagawad 6', coerce=int, validators=[DataRequired()])
    skkagawad7 = SelectField('SK Kagawad 7', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Add SK Council')

# Routes for adding SK Kagawad and SK Chairman


# Route for adding SK Council
# Import necessary modules
from flask import Flask, render_template, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
from wtforms.validators import DataRequired, ValidationError
import sqlite3

# ... (your other code)

# Define a custom validator for ensuring distinct values
def distinct_values(form, field):
    values = [form.skkagawad1.data, form.skkagawad2.data, form.skkagawad3.data,
              form.skkagawad4.data, form.skkagawad5.data, form.skkagawad6.data, form.skkagawad7.data]

    if len(set(values)) != len(values):
        raise ValidationError('SK Kagawad values must be distinct.')

# Define the SKCouncilForm with the custom validator
class SKCouncilForm(FlaskForm):
    skchairman = SelectField('SK Chairman', coerce=int, validators=[DataRequired()])
    skkagawad1 = SelectField('SK Kagawad 1', coerce=int, validators=[DataRequired(), distinct_values])
    skkagawad2 = SelectField('SK Kagawad 2', coerce=int, validators=[DataRequired(), distinct_values])
    skkagawad3 = SelectField('SK Kagawad 3', coerce=int, validators=[DataRequired(), distinct_values])
    skkagawad4 = SelectField('SK Kagawad 4', coerce=int, validators=[DataRequired(), distinct_values])
    skkagawad5 = SelectField('SK Kagawad 5', coerce=int, validators=[DataRequired(), distinct_values])
    skkagawad6 = SelectField('SK Kagawad 6', coerce=int, validators=[DataRequired(), distinct_values])
    skkagawad7 = SelectField('SK Kagawad 7', coerce=int, validators=[DataRequired(), distinct_values])
    submit = SubmitField('Add SK Council')

# ... (your other code)

# Route for adding SK Council
@app.route('/add_sk_council', methods=['GET', 'POST'])
def add_sk_council():
    form = SKCouncilForm()

    
    conn = sqlite3.connect('sk_voting.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id, chairman FROM skchairman')  
    sk_chairman_options = cursor.fetchall()
    conn.close()


    conn = sqlite3.connect('sk_voting.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id, kagawad FROM skkagawad')  
    sk_kagawad_options = cursor.fetchall()
    conn.close()

    # Set choices for SK Kagawad fields
    form.skchairman.choices = sk_chairman_options
    form.skkagawad1.choices = sk_kagawad_options
    form.skkagawad2.choices = sk_kagawad_options
    form.skkagawad3.choices = sk_kagawad_options
    form.skkagawad4.choices = sk_kagawad_options
    form.skkagawad5.choices = sk_kagawad_options
    form.skkagawad6.choices = sk_kagawad_options
    form.skkagawad7.choices = sk_kagawad_options

    if form.validate_on_submit():
        # Handle form submission here
        skchairman = form.skchairman.data
        skkagawad1 = form.skkagawad1.data
        skkagawad2 = form.skkagawad2.data
        skkagawad3 = form.skkagawad3.data
        skkagawad4 = form.skkagawad4.data
        skkagawad5 = form.skkagawad5.data
        skkagawad6 = form.skkagawad6.data
        skkagawad7 = form.skkagawad7.data

        # Insert data into the database
        conn = sqlite3.connect('sk_voting.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO users (skchairman, skkagawad1, skkagawad2, skkagawad3, skkagawad4, skkagawad5, skkagawad6, skkagawad7)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (skchairman, skkagawad1, skkagawad2, skkagawad3, skkagawad4, skkagawad5, skkagawad6, skkagawad7))
        conn.commit()
        conn.close()

        return render_template('success.html')  # Use a template for success

    return render_template('user_add_sk_council.html', form=form)

# ... (your other code)


if __name__ == '__main__':
    app.run(debug=True)
